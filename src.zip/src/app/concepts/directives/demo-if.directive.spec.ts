import { DemoIfDirective } from './demo-if.directive';

describe('DemoIfDirective', () => {
  it('should create an instance', () => {
    const directive = new DemoIfDirective();
    expect(directive).toBeTruthy();
  });
});
