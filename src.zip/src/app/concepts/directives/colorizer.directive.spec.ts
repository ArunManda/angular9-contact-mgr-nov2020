import { ColorizerDirective } from './colorizer.directive';

describe('ColorizerDirective', () => {
  it('should create an instance', () => {
    const directive = new ColorizerDirective();
    expect(directive).toBeTruthy();
  });
});
